# -*- coding: utf-8 -*-
""" How to gracefully load
"""
import sys

from direct.showbase.DirectObject import DirectObject
from pandac.PandaModules import * #Vec4
from direct.gui.OnscreenImage import OnscreenImage
from direct.gui.OnscreenText import OnscreenText
from direct.interval.IntervalGlobal import *
from direct.showbase.Transitions import Transitions
import direct.directbase.DirectStart

sound = loader.loadSfx('sound.mp3')

loadingimage = OnscreenImage('loading.png', color=(1,1,1,0), scale=.5, parent=aspect2d)
loadingimage.setTransparency(1)
# this image will be on top of all therefore we use setBin 'fixed' and with the higher sort value
loadingimage.setBin("fixed", 20)

curtain = OnscreenImage('black.png', parent=render2d)
curtain.setTransparency(1)
# this is to set it below the loading panel
curtain.setBin("fixed", 10)

# this text we want always on top so we don't set any bin
infotext=OnscreenText(
  text = 'Press s or p to start a loading sequence\nESC to exit', parent=aspect2d, pos = (0, .92), scale = 0.08, fg=(0,1,1,1), bg=(0,0,1,.7)
)

setuptext=OnscreenText(text = '', pos = (0, -0.85), scale = 0.07, mayChange=True, fg=(1,1,1,1), bg=(1,0,0,.65))
# we want this text to be put below the curtain and the loading panes lo we assigned the lowest sort order number
setuptext.setBin("fixed", 1)

models=[]
def setup(model):
  global loadingimage

  # unloading previous models
  for m in models:
    m.removeNode()
  
  # loading 10 pandas
  for x in range(-5, 5):
    m=loader.loadModel(model)
    m.reparentTo(render)
    m.setScale(.07)
    x2=(x/10.)*8
    m.setPos(x2,10.,-1.)
    models.append(m)

  setuptext.setText("We gracefully loaded 10 %ss"%model)

# the loading panel faders
loading_in=loadingimage.colorInterval(3, Vec4(1,1,1,1), Vec4(1,1,1,0))
loading_out=loadingimage.colorInterval(3, Vec4(1,1,1,0), Vec4(1,1,1,1))
# the black curtain faders
open_curtain = curtain.colorScaleInterval(3, Vec4(1,1,1,0), Vec4(1,1,1,1))
close_curtain = curtain.colorScaleInterval(3, Vec4(1,1,1,1), Vec4(1,1,1,0))

def start_sequence(model):
  #Sequence(close_curtain).start()
  #Sequence(loading_in, SoundInterval(sound), Func(setup, model), loading_out, open_curtain).start()
  Sequence(close_curtain, SoundInterval(sound), loading_in, Func(setup, model), Wait(2), loading_out, open_curtain).start()

DO=DirectObject()
DO.accept('p', start_sequence, ['panda'])
DO.accept('s', start_sequence, ['smiley'])
DO.accept('escape',sys.exit)

run()
